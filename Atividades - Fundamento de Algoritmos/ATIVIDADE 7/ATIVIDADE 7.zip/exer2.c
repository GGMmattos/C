#include <stdio.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    float temp[12], soma=0, media=0;
    int negative=0, igual=0, cont=1;

    for(int i=0; i < 12; i++){
        printf("\nInforme a %d� temperatura > ", cont);
        scanf("%f", &temp[i]);

        soma+=temp[i];

        if(temp[i] < 0)
            negative++;
            cont++;
    } printf("-----------------------------------------");
        cont=1;

    for(int i=0; i < 12; i++){
        printf("\npos > %d -  temperatura > %.2f�C \n", i, temp[i] );


     }for(int i=0; i < 11; i++){
            if(temp[i] == temp[11] )
                igual++;

}
    printf("\nNumero de temperaturas igual a ultima do periodo > %d ", igual);

}
